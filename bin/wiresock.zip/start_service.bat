@echo off
net session >nul 2>&1
if %errorLevel% neq 0 (
    powershell -NoProfile -Command "Start-Process '%~f0' -Verb RunAs -Wait"
    exit /b
)
net stop wiresock-client-service >nul 2>&1
net start wiresock-client-service > "C:\DiscordUnlock\bin\wiresock\service_start.log" 2>&1
sc query wiresock-client-service >> "C:\DiscordUnlock\bin\wiresock\service_start.log" 2>&1