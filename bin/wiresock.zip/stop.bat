@echo off
net stop wiresock-client-service
"C:\Program Files\WireSock Secure Connect\sdk\wiresock-client.exe" reset-network-lock